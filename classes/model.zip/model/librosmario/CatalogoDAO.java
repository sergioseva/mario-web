package model.librosmario;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;

public class CatalogoDAO {
	static Logger logger = Logger.getLogger(CatalogoDAO.class);

	public List<Catalogo> getCatalogos(String autor, String descripcion, String editorial, String tema, String isbn,boolean buscaComienzo) throws SQLException {
		List<Catalogo> list = new ArrayList<Catalogo>();
		Connection c = null;
		try {
		String select="SELECT * FROM cg_catalogo";
		String where="";
		String orderby="ORDER BY cg_descripcion";
		String comienzo="";
		DOMConfigurator.configure("log4j.xml");
		
		if (!buscaComienzo) 
		   {comienzo="%";}
		logger.debug("Hola1");
		String sql="";
		if (autor!="") 
			{where+= this.generaLike(autor, "cg_autor", buscaComienzo); }
		
		if (descripcion!="") 
			{where+= this.generaLike(descripcion, "cg_descripcion", buscaComienzo);}	
			
		if (editorial!="") 
			{where+=this.generaLike(editorial, "cg_editorial", buscaComienzo);};				
		
		if (tema!="") 
			{where+=this.generaLike(tema, "cg_tema", buscaComienzo); }

		if (isbn!="") 
			{where+=this.generaLike(isbn, "cg_isbn", buscaComienzo);}			

		logger.debug("where:" + where);	
		if 	(where!="") 
				{where=where.substring(0, where.length()-3-1);
				 where = "WHERE " + where;
				}
		
		logger.debug("Hola2");
		
			
		c = Sistema.getConnection();
		Statement s = c.createStatement();
		sql=select + " " + where +" "+ orderby;
		ResultSet rs = s.executeQuery(sql);
		
		
		while (rs.next()) {
		Catalogo catalogo = new Catalogo();
		catalogo.setCg_catalogo_k(rs.getInt("cg_catalogo_k"));
		catalogo.setCg_codigo_luongo(rs.getInt("cg_codigo_luongo"));
		catalogo.setCg_autor(rs.getString("cg_autor"));
		catalogo.setCg_descripcion(rs.getString("cg_descripcion"));
		catalogo.setCg_precio(rs.getDouble("cg_precio"));
		catalogo.setCg_pedido(rs.getInt("cg_pedido")); 
		catalogo.setCg_vigente(rs.getBoolean("cg_vigente"));
		catalogo.setCg_editorial(rs.getString("cg_editorial"));
		catalogo.setCg_tema(rs.getString("cg_tema"));
		catalogo.setCg_isbn(rs.getString("cg_isbn"));
		catalogo.setCg_pst(rs.getInt("cg_pst"));
		catalogo.setCg_observaciones(rs.getString("cg_observaciones"));
		catalogo.setCg_creador(rs.getString("cg_creador"));
		catalogo.setCg_inputdate(rs.getDate("cg_inputdate"));
		list.add(catalogo);
		}
		} finally {
		c.close();
		}
		return list;
		}

		public String update(Catalogo catalogo) throws SQLException {
		Connection connection = null;
		String result="";
		try {
		connection = Sistema.getConnection();
		connection.setAutoCommit(false);
		PreparedStatement ps = connection.prepareStatement("UPDATE cg_catalogo SET cg_autor=?, cg_descripcion=?, " +
				"cg_precio=?,cg_pedido=?,cg_editorial=?,cg_tema=?,cg_isbn=?, " +			
				"cg_pst=?,cg_observaciones=?,cg_creador=?,cg_inputdate=now() " +				
				"WHERE cg_catalogo_k=?");
		ps.setString(1, catalogo.getCg_autor() );
		ps.setString(2, catalogo.getCg_descripcion());
		ps.setDouble(3, catalogo.getCg_precio());
		ps.setInt(4, catalogo.getCg_pedido());
		ps.setString(5, catalogo.getCg_editorial());
		ps.setString(6, catalogo.getCg_tema());
		ps.setString(7, catalogo.getCg_isbn());
		ps.setInt(8, catalogo.getCg_pst());
		ps.setString(9, catalogo.getCg_observaciones());
		ps.setString(10, catalogo.getCg_creador());
		ps.setInt(11, catalogo.getCg_catalogo_k());
		ps.executeUpdate();			
		connection.commit();				
		logger.debug(ps.toString());
		result="ok";
		}
		catch (SQLException e) {
			try {
				connection.rollback();
				result="Error trying to update to the database: " + e.getMessage();
				logger.error("Error trying to update to the database: " + e.getMessage() );
			} catch (SQLException e1) {					
				logger.error(e1.getMessage());
			}					
		}
		return result;
		}
		
		public String insert(Catalogo catalogo) throws SQLException {
			Connection connection = null;
			Statement ps;
			String result="";
			
			connection = Sistema.getConnection();
			connection.setAutoCommit(false);
			logger.debug("insertando");
			String insert= "INSERT INTO librosmario.cg_catalogo ( cg_autor, cg_descripcion, " +
		      "cg_precio, cg_pedido, cg_editorial, cg_tema, cg_isbn, cg_pst, " +
		      "cg_observaciones, cg_creador,cg_inputdate) " +
		      " values ('" + catalogo.getCg_autor() + "','" + catalogo.getCg_descripcion() + "'," + catalogo.getCg_precio() + "," 
		      + 0 + ",'"  + catalogo.getCg_editorial() + "','" + catalogo.getCg_tema() + "','" + catalogo.getCg_isbn() + "'," + 0 + ",'"
		      + catalogo.getCg_observaciones() + "','librosmario',now());";
			logger.debug(insert);
			try {
				ps = connection.createStatement();
				ps.executeUpdate(insert);
				connection.commit();	
				logger.debug("insert�:" + insert);
				result="ok";
			}
			catch (SQLException e) {
			try {
					logger.error("Error trying to insert to the database: " + e.getMessage() + 
					"insert: " + insert);					
					connection.rollback();
					result= "Error trying to insert to the database: " + e.getMessage() + 
					"insert: " + insert;
				} catch (SQLException e1) {					
					logger.error(e1.getMessage());
				}
								
			}
			return result;
		}
		
		public String generaLike(String busqueda,String campo,boolean buscaComienzo ) {
			String like="";			
			try {
			if (buscaComienzo) 
			   {like= " " + campo + " like '" + busqueda + "%' AND"; }
			else
				{
				String []split=busqueda.split(" "); 
				int i=0;
				for (i=0;i<split.length;i++) {
					like+= " " + campo + " like '%" + split[i].trim() + "%' AND";
					logger.debug(like);
				};
			}
			logger.debug("retorno like");			
			
			} catch (Exception e) {
				logger.error(e.getMessage());				
			}
			return like;
		}
	
}
