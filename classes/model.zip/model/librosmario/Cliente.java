package model.librosmario;

public class Cliente {
	 int cl_cliente_k;
	 String cl_nombre;
	 String cl_direccion;
	 String cl_telefono_fijo;
	 String cl_telefono_movil;
	 String cl_telefono_laboral;
	 String cl_telefono_otro;
	 String cl_telefono_otro_descr;
	 String cl_email;
	 
	public int getCl_cliente_k() {
		return cl_cliente_k;
	}
	public void setCl_cliente_k(int cl_cliente_k) {
		this.cl_cliente_k = cl_cliente_k;
	}
	public String getCl_nombre() {
		return cl_nombre;
	}
	public void setCl_nombre(String cl_nombre) {
		this.cl_nombre = cl_nombre;
	}
	public String getCl_direccion() {
		return cl_direccion;
	}
	public void setCl_direccion(String cl_direccion) {
		this.cl_direccion = cl_direccion;
	}
	public String getCl_telefono_fijo() {
		return cl_telefono_fijo;
	}
	public void setCl_telefono_fijo(String cl_telefono_fijo) {
		this.cl_telefono_fijo = cl_telefono_fijo;
	}
	public String getCl_telefono_movil() {
		return cl_telefono_movil;
	}
	public void setCl_telefono_movil(String cl_telefono_movil) {
		this.cl_telefono_movil = cl_telefono_movil;
	}
	public String getCl_telefono_laboral() {
		return cl_telefono_laboral;
	}
	public void setCl_telefono_laboral(String cl_telefono_laboral) {
		this.cl_telefono_laboral = cl_telefono_laboral;
	}
	public String getCl_telefono_otro() {
		return cl_telefono_otro;
	}
	public void setCl_telefono_otro(String cl_telefono_otro) {
		this.cl_telefono_otro = cl_telefono_otro;
	}
	public String getCl_telefono_otro_descr() {
		return cl_telefono_otro_descr;
	}
	public void setCl_telefono_otro_descr(String cl_telefono_otro_descr) {
		this.cl_telefono_otro_descr = cl_telefono_otro_descr;
	}
	public String getCl_email() {
		return cl_email;
	}
	public void setCl_email(String cl_email) {
		this.cl_email = cl_email;
	}
}
