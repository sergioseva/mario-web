package model.librosmario;

import java.io.*;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.sql.DataSource;

import org.apache.commons.dbcp.BasicDataSource;
import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;

import com.linuxense.javadbf.*;
import com.mysql.jdbc.PreparedStatement;

public class CatalogoConverter {
	static Logger logger = Logger.getLogger(CatalogoConverter.class);
	

	public String importarLuongo ()  {		
		final int CODIGO=0;
		final int AUTOR=1;
		final int DESCRIPCION=2;
		final int PRECIO=3;
		final int PEDIDO=4;
		final int VIGENTE=5;
		final int EDITORIAL=6;
		final int TEMA=7;
		final int ISBN=8;
		final int PSTOCK=9;
		final int OBSERVACIONES=10;
		
		int codigo;
		String autor;
		String descripcion;
		Double precio;
		int pedido;
		Boolean vigente;
		String editorial;
		String tema;
		long isbn;
		int pstock;
		String observaciones;
		Connection connection = null;
		Statement ps;
		DOMConfigurator.configure("log4j.xml");
		logger.debug("importar luongo");
	
		try{
			try	{
			connection=Sistema.getConnection();			
			connection.setAutoCommit(false);
			}
			catch( SQLException e) {
				logger.error("Error trying to connecto to the database: " + e.getMessage());
			}
		logger.debug("importar luongo 1");
		InputStream inputStream = new FileInputStream("C:\\luongo\\ART.DBF"); // take dbf file as program argument
		logger.debug("importar luongo 2");
		DBFReader reader = new DBFReader( inputStream);
		// get the field count if you want for some reasons like the following
		//
		logger.debug("importar luongo 3");
		int numberOfFields = reader.getFieldCount();
		// use this count to fetch all field information
		// if required
		//
		for( int i=0; i<numberOfFields; i++) {
		DBFField field = reader.getField( i);
		// do something with it if you want
		// refer the JavaDoc API reference for more details
		//
		logger.debug( field.getName());
		}
		// Now, lets us start reading the rows
		//
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		logger.debug(dateFormat.format(date));
		
		
		try	{						
			connection.setAutoCommit(false);		
			ps=connection.createStatement();
			ps.execute(" SET SQL_SAFE_UPDATES=0;");
			ps.execute("delete from librosmario.cg_catalogo " +
					"where cg_creador='luongo';");
			}
			catch( SQLException e) {
				logger.error("Error deleting catalogo: " + e.getMessage());
			}
		
			logger.debug("Cantidad de registros: " + reader.getRecordCount());
		
		Object []rowObjects;
		while( (rowObjects = reader.nextRecord()) != null) {
		
		if (rowObjects[CODIGO]!=null) {
			precio=null;
			pedido=0;
			pstock=0;
			isbn=0;
			
			codigo=	 ((Double) rowObjects[CODIGO]).intValue();			
			//System.out.println( codigo);
			autor=((String) rowObjects[AUTOR]).replace("'","''");
			
			//System.out.println( autor);
			descripcion=((String) rowObjects[DESCRIPCION]).replace("'","''");
			//System.out.println( descripcion);
			if (rowObjects[PRECIO]!=null) {
				precio=(Double) rowObjects[PRECIO];
				//System.out.println( precio);
			} 
			if (rowObjects[PEDIDO]!=null) {
				pedido=	 ((Double) rowObjects[PEDIDO]).intValue();			
				//System.out.println( pedido);
			}
			vigente=(Boolean) rowObjects[VIGENTE];			
			//System.out.println( vigente);
			editorial=((String) rowObjects[EDITORIAL]).replace("'","''");;
			//System.out.println( editorial);
			tema=((String) rowObjects[TEMA]).replace("'","''");;
			//System.out.println( tema);
			if (rowObjects[ISBN]!=null) {
				isbn=((Double) rowObjects[ISBN]).longValue();
				//System.out.println( isbn);
			}
			if (rowObjects[PSTOCK]!=null) {
				pstock=	 ((Double) rowObjects[PSTOCK]).intValue();			
				//System.out.println( pstock);
			} 
			observaciones=((String) rowObjects[OBSERVACIONES]).replace("'","''");;
			//System.out.println( observaciones);
			String insert= "INSERT INTO librosmario.cg_catalogo (cg_codigo_luongo, cg_autor, cg_descripcion, " +
		      "cg_precio, cg_pedido, cg_editorial, cg_tema, cg_isbn, cg_pst, " +
		      "cg_observaciones, cg_creador,cg_inputdate) " +
		      " values ("+ codigo +",'" + autor + "','" + descripcion + "'," + precio + "," 
		      + pedido + ",'"  + editorial + "','" + tema + "','" + isbn + "'," + pstock + ",'"
		      + observaciones + "','luongo',now());";
			try {
				ps = connection.createStatement();
				ps.executeUpdate(insert);
				connection.commit();				
			}
			catch (SQLException e) {
				try {
					connection.rollback();
				} catch (SQLException e1) {					
					logger.error(e1.getMessage());
				}
				logger.error("Error trying to insert to the database: " + e.getMessage() + 
						"insert: " + insert);				
			}
			   
			}//if
		
		}//while
		
		// By now, we have iterated through all of the rows
		inputStream.close();
		date = new Date();
		logger.debug(dateFormat.format(date));
  	    
		}
		catch( DBFException e) {
			logger.error("DBFException:" + e.getMessage());
			return "Error, comuniquese con el soporte";
		}
		catch( FileNotFoundException e) {
			logger.error("FileNotFoundException:" + e.getMessage());
			return "Archivo no encontrado:" + e.getMessage();
		}	
		catch( IOException e) {
			logger.error("IOException:" + e.getMessage());
			return "Error, comuniquese con el soporte";
		}	
		catch( Exception e) {
			logger.error("Exception:" + e.toString() );
			return "Error, comuniquese con el soporte";
		}
		finally { 
			   try {
			      if (null != connection) {
			         connection.close();
			      }
			   } catch (SQLException e) {
				   logger.error("Error trying to close the connection:" + e.getMessage());
		}		
	}	
		
	return "Catalogo importado correctamente";
		
	
 }

}