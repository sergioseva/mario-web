package model.librosmario;

public class Editorial {
  private int ed_editorial_k;
  private String ed_descripcion;
public int getEd_editorial_k() {
	return ed_editorial_k;
}
public void setEd_editorial_k(int ed_editorial_k) {
	this.ed_editorial_k = ed_editorial_k;
}
public String getEd_descripcion() {
	return ed_descripcion;
}
public void setEd_descripcion(String ed_descripcion) {
	this.ed_descripcion = ed_descripcion;
}
}
