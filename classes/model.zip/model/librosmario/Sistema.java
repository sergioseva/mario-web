package model.librosmario;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;
import org.apache.commons.dbcp.BasicDataSource;
import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;



public class Sistema {
	static Logger logger = Logger.getLogger(Sistema.class);
	DataSource pool;
	private static Sistema instance;
	public Sistema() {
		 pool=new BasicDataSource();
		 //TODO poner esto en un archivo, http://www.chuidiang.com/java/mysql/BasicDataSource-Pool-Conexiones.php
		((BasicDataSource) pool).setDriverClassName("com.mysql.jdbc.Driver");
		((BasicDataSource) pool).setUrl("jdbc:mysql://localhost:3306/librosmario");
		((BasicDataSource) pool).setUsername("root");
		((BasicDataSource) pool).setPassword("dracula");
		DOMConfigurator.configure("log4j.xml");
	}
	
	public void importarCatalogo() {
		CatalogoConverter catalogoConverter;
	    catalogoConverter=new CatalogoConverter();
	    /*catalogoConverter.importarLuongo();*/	
	}
	
	public static Connection getConnection() throws SQLException {
		if (instance == null) {
			instance = new Sistema();
		}
		try {
			return instance.pool.getConnection();
		} catch (SQLException e) {
			throw e;
		}
	}
	
	public Pedido nuevoPedido() {
		return (new Pedido());
	}
	
	public List<PedidoItem> agregarItemAPedido(Pedido p, PedidoItem pi) {
		logger.debug("p.addPedido(pi);");
		p.addPedido(pi);
		logger.debug("p.addPedido(pi)2;");
		return p.getItems();
	}
	
	public void grabarPedido(Pedido p) {

	}
	
}