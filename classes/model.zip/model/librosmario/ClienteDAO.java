package model.librosmario;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;

public class ClienteDAO {
	static Logger logger = Logger.getLogger(ClienteDAO.class);

	public List<Cliente> getClientes() {
		List<Cliente> list = new ArrayList<Cliente>();
		Connection c = null;
		String sql="";
		String select="SELECT cl_cliente_k,cl_direccion,cl_email,cl_nombre,cl_telefono_fijo,cl_telefono_laboral,cl_telefono_movil,cl_telefono_otro,cl_telefono_otro_descr FROM librosmario.cl_cliente";		
		String orderby="ORDER BY cl_nombre;";
		DOMConfigurator.configure("log4j.xml");
		
		try {
		logger.debug("hola cliente");	
		c = Sistema.getConnection();
		Statement s = c.createStatement();
		sql=select + " " + orderby;
		ResultSet rs = s.executeQuery(sql);
		
		while (rs.next()) {
			Cliente cliente=new Cliente();		
			logger.debug(rs.getString("cl_cliente_k"));
			cliente.setCl_cliente_k(rs.getInt("cl_cliente_k"));
			logger.debug("cl_direccion :" + rs.getString("cl_direccion"));
			cliente.setCl_direccion(rs.getString("cl_direccion"));
			logger.debug("cl_email:" + rs.getString("cl_email"));
			//cliente.setCl_email(rs.getString(rs.getString("cl_email")));
			logger.debug("cl_nombre:" + rs.getString("cl_nombre"));
			cliente.setCl_nombre(rs.getString("cl_nombre"));
			logger.debug(rs.getString("cl_telefono_fijo"));
			cliente.setCl_telefono_fijo(rs.getString("cl_telefono_fijo"));
			logger.debug(rs.getString("cl_telefono_laboral"));
			cliente.setCl_telefono_laboral(rs.getString("cl_telefono_laboral"));
			logger.debug(rs.getString("cl_telefono_movil"));
			cliente.setCl_telefono_movil(rs.getString("cl_telefono_movil"));
			logger.debug(rs.getString("cl_telefono_otro"));
			cliente.setCl_telefono_otro(rs.getString("cl_telefono_otro"));
			logger.debug(rs.getString("cl_telefono_otro_descr"));
			cliente.setCl_telefono_otro_descr(rs.getString("cl_telefono_otro_descr"));
			list.add(cliente);
		}
		
		}  
		
		catch (SQLException e)
		{
			logger.error("Error trying to query to the database: " + e.getMessage() + 
					"select: " + sql);
			} catch (Exception e) {
			logger.error("Error : " + e.getMessage() + 
					"in ClienteDAO:" + select);
		}
		
		finally {
			try {
			c.close();
			} catch (SQLException e1) {					
				logger.error(e1.getMessage());
			}
		}
		return list;
	}
	
	
}
